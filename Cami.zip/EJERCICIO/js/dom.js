console.log("Entramos");

var items = document.getElementsByClassName("item");

var cantidad= items.length; 

console.log(cantidad);

console.log("Cantidad de listas " + cantidad);

var div = document.createElement("div");

div;

div.innerText= "Aprendiendo JavaScript";

var divUno = document.getElementById("uno");

divUno.appendChild(div);


var lista=document.getElementById("lista");

var hijo= document.createElement("li"); 
hijo.innerText = "li nuevo";

lista.appendChild(hijo);

document.getElementById("tres").style.color="red";
document.getElementById("lista").style.color="green";

var cuerpo = document.getElementById("cuerpo");
var div= document.createElement("div");
cuerpo.appendChild(div);

var texto=document.createElement("p");

texto.innerText = "Un vodka con hielo, Llegué pa hablar y habían tres baretos en el cenicero, Tú resaltas, Estabas tan chimba, toda arreglada hasta el pelo, ey, uy, No estaba fácil esa noche, ey, Me estabas peleando por lo del bote, Yo pensando en tu cuerpo y tú pensando lo peor, Dime, mami, ¿qué lo que?, ah, Otra vez, otra vez en la playa de Belice, Otra vez, otra vez, cuando la tanga te deslicé";
div.appendChild(texto);




















